---
doc_id: R-014
data_class: C2
kind: METADATA
owner_project: SAURIA
sensitive_level: confidential
---
# SAURIA — Ghi chú tích hợp (nội bộ)
Ghi chú tích hợp SAURIA vào luồng VSI: ranh giới IP, mirror nội bộ, Docker tự dựng.
