---
doc_id: R-012
data_class: C2
kind: PROGRESS_REPORT
owner_project: SOVRA
owner_dept: DV
required_tags: disc-dv
sensitive_level: confidential
---
# DV — Bảng triage bug
Triage bug DV: phân loại, mức ưu tiên, owner; cần tag disc-dv.
