---
doc_id: R-008
data_class: C2
data_subclass: PII
kind: PII
is_personnel_report: true
subject_person: eng_pd1
sensitive_level: confidential
---
# Hồ sơ nhân sự — eng_pd1
Đánh giá hiệu suất, lương, lịch sử dự án của eng_pd1.
