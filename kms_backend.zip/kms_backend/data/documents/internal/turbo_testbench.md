---
doc_id: R-013
data_class: C2
kind: TESTBENCH
owner_project: SOVRA
sensitive_level: confidential
---
# Turbo Encoder — Testbench (tóm tắt)
Testbench UVM cho Turbo Encoder: coverage plan, plusargs blk_size, kịch bản directed/random.
