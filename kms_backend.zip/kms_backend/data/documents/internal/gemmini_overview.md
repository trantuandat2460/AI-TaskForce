---
doc_id: R-003
data_class: C2
kind: SPEC_OVERVIEW
owner_project: SOVRA
sensitive_level: confidential
---
# Gemmini — Kiến trúc systolic array
## Thành phần
Gemmini là DNN accelerator: systolic array, scratchpad/accumulator, DMA, giao tiếp RoCC, decoupled access/execute.
