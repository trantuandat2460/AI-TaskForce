---
doc_id: R-011
data_class: C1
kind: PUBLIC
sensitive_level: internal
---
# Sổ tay onboarding
## Quy trình
Hướng dẫn onboarding chung cho nhân viên mới: quy trình, công cụ, văn hoá.
## Công cụ
Git, Jira, Confluence, EDA nội bộ.
