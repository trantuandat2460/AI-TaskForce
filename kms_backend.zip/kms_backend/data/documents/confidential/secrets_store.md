---
doc_id: R-010
data_class: C3
kind: METADATA
owner_dept: IT
is_credential: true
sensitive_level: restricted
---
# Khoá API / Secrets store
(credential — chặn cứng, không bao giờ đưa vào AI)
