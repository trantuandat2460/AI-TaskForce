---
doc_id: R-002
data_class: C3
data_subclass: C3_CORE_IP
kind: SPEC_DETAIL
owner_project: SOVRA
required_tags: core-ip
sensitive_level: restricted
---
# Mô hình phân quyền DCM (chi tiết)
## Công thức
Mô hình DCM dùng effective = min(clearance, limit); fail-closed.
## PDP
PDP authorize() 8 bước: DCM gate → ABAC → cô lập dự án → scope phòng → ReBAC nhân sự → trần vai trò.
