---
doc_id: R-005
data_class: C3
data_subclass: C3_CORE_IP
kind: IP
owner_project: SAURIA
owner_dept: PHYSICAL
required_tags: core-ip
sensitive_level: restricted
---
# SAURIA — RTL datapath
## Datapath
Datapath systolic của SAURIA (BSC): PE array, FIFO biên, điều khiển load/compute; tham số hoá kích thước mảng.
