---
doc_id: R-007
data_class: C3
kind: FOUNDRY
owner_dept: PHYSICAL
sensitive_level: restricted
---
# PDK — Ràng buộc timing (Foundry)
## Bảng
Bảng ràng buộc timing PDK foundry: setup/hold, corner, derate; chỉ phòng Physical được truy cập.
