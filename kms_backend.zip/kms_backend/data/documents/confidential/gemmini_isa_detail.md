---
doc_id: R-004
data_class: C3
data_subclass: C3_CORE_IP
kind: SPEC_DETAIL
owner_project: SOVRA
required_tags: core-ip
sensitive_level: restricted
---
# Gemmini — RoCC ISA (chi tiết)
## Tập lệnh
Tập lệnh RoCC của Gemmini: mvin/mvout, matmul, config; mã hoá custom opcode; ràng buộc fence và pipeline.
