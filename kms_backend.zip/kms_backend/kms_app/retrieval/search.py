"""Truy hồi (mô phỏng vector search bằng overlap keyword trên chunk). Loại
stopword tiếng Việt để giảm nhiễu. Trả list chunk-row; PEP-1 đã lọc doc trước."""
import re, json

STOP = {"của","và","các","là","một","có","cho","khi","thế","nào","hoạt","động","được","theo",
        "với","trong","này","đó","thì","sao","như","về","đến","từ","ra","vào","trên","dưới",
        "hãy","tôi","bạn","cái","gì","những","để","làm","còn","hỏi","xem","cách"}

def _tok(s):
    return {t for t in re.findall(r"[a-zà-ỹ0-9_]{3,}", s.lower()) if t not in STOP}

def retrieve(conn, query, allowed_doc_ids, top_k=5):
    if not allowed_doc_ids:
        return []
    qtok = _tok(query)
    if not qtok:
        return []
    ph = ",".join("?" * len(allowed_doc_ids))
    rows = conn.execute(f"SELECT * FROM chunks WHERE doc_id IN ({ph})", tuple(allowed_doc_ids)).fetchall()
    docs = {r["doc_id"]: r for r in conn.execute(f"SELECT doc_id,title FROM documents WHERE doc_id IN ({ph})", tuple(allowed_doc_ids)).fetchall()}
    scored = []
    for r in rows:
        kw = set(json.loads(r["keywords_json"] or "[]")) - STOP
        title_tok = _tok(docs[r["doc_id"]]["title"] if r["doc_id"] in docs else "")
        s = 2 * len(qtok & kw) + 2 * len(qtok & title_tok)
        # bonus nhẹ cho heading khớp
        s += len(qtok & _tok(r["heading_path"] or ""))
        if s > 0:
            scored.append((s, r))
    scored.sort(key=lambda x: x[0], reverse=True)
    # gộp theo doc: ưu tiên chunk điểm cao nhất mỗi doc để đủ đa dạng nguồn
    seen, out = set(), []
    for _, r in scored:
        if r["doc_id"] in seen:
            continue
        seen.add(r["doc_id"]); out.append(r)
        if len(out) >= top_k:
            break
    return out
