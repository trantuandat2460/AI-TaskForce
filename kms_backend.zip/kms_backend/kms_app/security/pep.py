"""PEP kép (A4/P22):
  - pep1_filter_docs: lọc thô theo permission_group (MatchAny) — rẻ.
  - pep2_authorize:   recheck từng resource bằng authorize() — defense-in-depth.
  - max_class:        highest-classification-wins (P15)."""
from config.settings import CLASS_RANK
from kms_app.security.pdp import authorize

def pep1_filter_docs(subject, docs):
    return [d for d in docs if d["permission_group"] in subject["groups"]]

def pep2_authorize(subject, resources):
    allowed, denied = [], []
    for r in resources:
        d = authorize(subject, r)
        (allowed if d.allow else denied).append((r, d))
    return allowed, denied

def max_class(resources):
    mdc = "C1"
    for r in resources:
        if CLASS_RANK[r["data_class"]] > CLASS_RANK[mdc]:
            mdc = r["data_class"]
    return mdc
