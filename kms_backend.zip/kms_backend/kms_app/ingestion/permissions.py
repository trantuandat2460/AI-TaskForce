"""Phân giải thuộc tính quyền cho mỗi tài liệu. Ở bản này, mỗi file .md mang
front-matter (--- ... ---) khai báo data_class/kind/owner_project/... nên BẠN
mở file ra là thấy ngay phân loại. Thư mục cha (public/internal/confidential)
gợi ý permission_group mặc định nếu front-matter thiếu."""
FOLDER_GROUP = {"public": "vsi_public", "internal": "vsi_internal", "confidential": "vsi_confidential"}

def parse_front_matter(text):
    meta, body = {}, text
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            block = text[3:end].strip()
            body = text[end+4:].lstrip("\n")
            for line in block.splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = v.strip()
    return meta, body

def coerce(meta, folder):
    def lst(s): return [x.strip() for x in s.split(",") if x.strip()] if s else []
    def bol(s): return str(s).lower() in ("1","true","yes","y")
    return {
        "data_class":      meta.get("data_class", "C2"),
        "data_subclass":   meta.get("data_subclass"),
        "kind":            meta.get("kind", "METADATA"),
        "owner_project":   meta.get("owner_project") or None,
        "owner_dept":      meta.get("owner_dept") or None,
        "required_tags":   lst(meta.get("required_tags")),
        "permission_group":meta.get("permission_group") or FOLDER_GROUP.get(folder, "vsi_internal"),
        "sensitive_level": meta.get("sensitive_level", "confidential"),
        "is_credential":   bol(meta.get("is_credential")),
        "is_personnel_report": bol(meta.get("is_personnel_report")),
        "subject_person":  meta.get("subject_person") or None,
    }
