"""Pipeline ingest: docling(→markdown) → chunk → upsert vào SQLite. Idempotent
qua 2 fingerprint: content_fp (sha256 bytes) → re-embed; perm_fp (sha256 thuộc
tính) → chỉ cập nhật payload. (Bản này: nguồn đã là .md nên 'docling' là no-op,
nhưng pipeline để sẵn chỗ cắm docling thật cho PDF — chạy offline trong lane.)"""
import hashlib, json, datetime
from pathlib import Path
from config import settings
from kms_app import db
from kms_app.ingestion import permissions as P
from kms_app.ingestion import chunking

def _now(): return datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

def docling_to_markdown(path: Path) -> str:
    """Chỗ cắm docling. Với .md trả nguyên văn. Với .pdf/.docx: gọi docling ở đây.
    QUAN TRỌNG: docling phải chạy offline trong lane (A15/P33)."""
    return path.read_text(encoding="utf-8", errors="ignore")

def ingest_all(conn):
    report = {"new": 0, "changed": 0, "perm_changed": 0, "unchanged": 0, "chunks": 0, "files": 0}
    base = settings.DOCUMENTS_DIR
    for path in sorted(base.rglob("*.md")):
        report["files"] += 1
        folder = path.parent.name
        raw = path.read_text(encoding="utf-8", errors="ignore")
        meta, _ = P.parse_front_matter(raw)
        attrs = P.coerce(meta, folder)
        md = docling_to_markdown(path)
        _, body = P.parse_front_matter(md)
        doc_id = meta.get("doc_id") or path.stem
        import re as _re
        _h1 = _re.search(r"^#\s+(.+)$", body, _re.M)
        title = _h1.group(1).strip() if _h1 else path.stem
        content_fp = hashlib.sha256(raw.encode()).hexdigest()[:16]
        perm_fp = hashlib.sha256(json.dumps({k: attrs[k] for k in
                  ("data_class","kind","owner_project","owner_dept","required_tags","permission_group","sensitive_level","is_credential","is_personnel_report","subject_person")},
                  sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]

        row = conn.execute("SELECT content_fp, perm_fp FROM documents WHERE doc_id=?", (doc_id,)).fetchone()
        rel = str(path.relative_to(settings.BASE_DIR))
        if row is None:
            status = "new"
        elif row["content_fp"] != content_fp:
            status = "changed"
        elif row["perm_fp"] != perm_fp:
            status = "perm_changed"
        else:
            report["unchanged"] += 1
            continue

        conn.execute("""INSERT OR REPLACE INTO documents
            (doc_id,business_key,source_file,title,file_kind,data_class,data_subclass,kind,owner_project,owner_dept,
             required_tags_json,permission_group,sensitive_level,is_credential,is_personnel_report,subject_person,
             content_fp,perm_fp,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (doc_id, doc_id, rel, title, "markdown", attrs["data_class"], attrs["data_subclass"], attrs["kind"],
             attrs["owner_project"], attrs["owner_dept"], json.dumps(attrs["required_tags"]),
             attrs["permission_group"], attrs["sensitive_level"], int(attrs["is_credential"]),
             int(attrs["is_personnel_report"]), attrs["subject_person"], content_fp, perm_fp, _now(), _now()))

        if status in ("new", "changed"):  # re-embed chunks
            conn.execute("DELETE FROM chunks WHERE doc_id=?", (doc_id,))
            for ch in chunking.chunk_markdown(doc_id, body):
                conn.execute("""INSERT INTO chunks(chunk_id,doc_id,parent_id,heading_path,chunk_level,chunk_index,text,keywords_json)
                    VALUES(?,?,?,?,?,?,?,?)""",
                    (ch["chunk_id"], doc_id, ch["parent_id"], ch["heading_path"], ch["chunk_level"],
                     ch["chunk_index"], ch["text"], json.dumps(ch["keywords"], ensure_ascii=False)))
                report["chunks"] += 1
        report[status] += 1
        conn.commit()
    return report
