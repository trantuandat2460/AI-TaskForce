"""Seed dữ liệu demo: users (PBKDF2) + ghi các file .md mẫu vào data/documents/
(có front-matter để bạn mở ra là thấy phân loại) + ingest + 1 hội thoại mẫu."""
import json, datetime
from config import settings
from kms_app import db
from kms_app.security import passwords
from kms_app.ingestion import store as istore

USERS = [
  ("admin1","ADMIN","IT","C3",["core-ip","proj-sovra","proj-sauria","lead","pmo","disc-pd","disc-dv","hr"],
   ["vsi_public","vsi_internal","vsi_confidential"],["SOVRA","SAURIA"],["eng_pd1","eng_dv1","lead_dv"],1),
  ("eng_pd1","ENGINEER","PHYSICAL","C3",["core-ip","proj-sovra","disc-pd"],
   ["vsi_public","vsi_internal","vsi_confidential"],["SOVRA"],[],0),
  ("lead_dv","LEADER","DV","C3",["lead","proj-sovra","disc-dv"],
   ["vsi_public","vsi_internal","vsi_confidential"],["SOVRA"],["eng_dv1"],0),
  ("pm1","PM","PMO","C2",["pmo","proj-sovra"],["vsi_public","vsi_internal"],["SOVRA"],[],0),
  ("hr1","HR","HR","C2",["hr"],["vsi_public","vsi_internal"],[],[],1),
]

# (relative folder, filename, front-matter dict, body)
DOCS = [
 ("public","onboarding.md",
  dict(doc_id="R-011",data_class="C1",kind="PUBLIC",sensitive_level="internal"),
  "# Sổ tay onboarding\n## Quy trình\nHướng dẫn onboarding chung cho nhân viên mới: quy trình, công cụ, văn hoá.\n## Công cụ\nGit, Jira, Confluence, EDA nội bộ."),
 ("internal","sovra_kms_overview.md",
  dict(doc_id="R-001",data_class="C2",kind="SPEC_OVERVIEW",owner_project="SOVRA",sensitive_level="confidential"),
  "# SOVRA KMS — Thiết kế tổng quan\n## Mục tiêu\nKMS là kho tri thức nội bộ an toàn kết hợp lớp agentic-RAG.\n## Phạm vi\nPhục vụ truy hồi tài liệu kỹ thuật với kiểm soát truy cập theo tổ chức."),
 ("confidential","sovra_dcm_detail.md",
  dict(doc_id="R-002",data_class="C3",data_subclass="C3_CORE_IP",kind="SPEC_DETAIL",owner_project="SOVRA",required_tags="core-ip",sensitive_level="restricted"),
  "# Mô hình phân quyền DCM (chi tiết)\n## Công thức\nMô hình DCM dùng effective = min(clearance, limit); fail-closed.\n## PDP\nPDP authorize() 8 bước: DCM gate → ABAC → cô lập dự án → scope phòng → ReBAC nhân sự → trần vai trò."),
 ("internal","gemmini_overview.md",
  dict(doc_id="R-003",data_class="C2",kind="SPEC_OVERVIEW",owner_project="SOVRA",sensitive_level="confidential"),
  "# Gemmini — Kiến trúc systolic array\n## Thành phần\nGemmini là DNN accelerator: systolic array, scratchpad/accumulator, DMA, giao tiếp RoCC, decoupled access/execute."),
 ("confidential","gemmini_isa_detail.md",
  dict(doc_id="R-004",data_class="C3",data_subclass="C3_CORE_IP",kind="SPEC_DETAIL",owner_project="SOVRA",required_tags="core-ip",sensitive_level="restricted"),
  "# Gemmini — RoCC ISA (chi tiết)\n## Tập lệnh\nTập lệnh RoCC của Gemmini: mvin/mvout, matmul, config; mã hoá custom opcode; ràng buộc fence và pipeline."),
 ("confidential","sauria_rtl.md",
  dict(doc_id="R-005",data_class="C3",data_subclass="C3_CORE_IP",kind="IP",owner_project="SAURIA",owner_dept="PHYSICAL",required_tags="core-ip",sensitive_level="restricted"),
  "# SAURIA — RTL datapath\n## Datapath\nDatapath systolic của SAURIA (BSC): PE array, FIFO biên, điều khiển load/compute; tham số hoá kích thước mảng."),
 ("internal","ws4_weekly_w23.md",
  dict(doc_id="R-006",data_class="C2",kind="PROGRESS_REPORT",owner_project="SOVRA",sensitive_level="confidential"),
  "# Báo cáo tuần WS4 — Week 23\n## Đạt được\nHoàn thiện đăng nhập + điều khiển truy cập theo vai trò cho cổng nội bộ; 59/59 self-test PASS.\n## Rủi ro\nFirewall chặn hạ tầng bên ngoài.\n## Tuần tới\nKhảo sát n8n và tự động hoá luồng."),
 ("confidential","pdk_timing.md",
  dict(doc_id="R-007",data_class="C3",kind="FOUNDRY",owner_dept="PHYSICAL",sensitive_level="restricted"),
  "# PDK — Ràng buộc timing (Foundry)\n## Bảng\nBảng ràng buộc timing PDK foundry: setup/hold, corner, derate; chỉ phòng Physical được truy cập."),
 ("internal","personnel_eng_pd1.md",
  dict(doc_id="R-008",data_class="C2",data_subclass="PII",kind="PII",is_personnel_report="true",subject_person="eng_pd1",sensitive_level="confidential"),
  "# Hồ sơ nhân sự — eng_pd1\nĐánh giá hiệu suất, lương, lịch sử dự án của eng_pd1."),
 ("internal","personnel_eng_dv1.md",
  dict(doc_id="R-009",data_class="C2",data_subclass="PII",kind="PII",is_personnel_report="true",subject_person="eng_dv1",sensitive_level="confidential"),
  "# Hồ sơ nhân sự — eng_dv1\nĐánh giá hiệu suất, lương, lịch sử dự án của eng_dv1."),
 ("confidential","secrets_store.md",
  dict(doc_id="R-010",data_class="C3",kind="METADATA",owner_dept="IT",is_credential="true",sensitive_level="restricted"),
  "# Khoá API / Secrets store\n(credential — chặn cứng, không bao giờ đưa vào AI)"),
 ("internal","dv_bug_triage.md",
  dict(doc_id="R-012",data_class="C2",kind="PROGRESS_REPORT",owner_project="SOVRA",owner_dept="DV",required_tags="disc-dv",sensitive_level="confidential"),
  "# DV — Bảng triage bug\nTriage bug DV: phân loại, mức ưu tiên, owner; cần tag disc-dv."),
 ("internal","turbo_testbench.md",
  dict(doc_id="R-013",data_class="C2",kind="TESTBENCH",owner_project="SOVRA",sensitive_level="confidential"),
  "# Turbo Encoder — Testbench (tóm tắt)\nTestbench UVM cho Turbo Encoder: coverage plan, plusargs blk_size, kịch bản directed/random."),
 ("internal","sauria_integration.md",
  dict(doc_id="R-014",data_class="C2",kind="METADATA",owner_project="SAURIA",sensitive_level="confidential"),
  "# SAURIA — Ghi chú tích hợp (nội bộ)\nGhi chú tích hợp SAURIA vào luồng VSI: ranh giới IP, mirror nội bộ, Docker tự dựng."),
]

def _fm(meta):
    lines = ["---"] + [f"{k}: {v}" for k, v in meta.items()] + ["---", ""]
    return "\n".join(lines)

def write_documents():
    for folder, name, meta, body in DOCS:
        d = settings.DOCUMENTS_DIR / folder
        d.mkdir(parents=True, exist_ok=True)
        (d / name).write_text(_fm(meta) + body + "\n", encoding="utf-8")

def seed_users(conn):
    for uid, role, dept, cl, tags, groups, projects, manages, hr in USERS:
        conn.execute("""INSERT OR REPLACE INTO users
            (user_id,role,department,clearance,pw_hash,tags_json,groups_json,projects_json,manages_json,hr_purpose)
            VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (uid, role, dept, cl, passwords.hash_password(uid),
             json.dumps(tags), json.dumps(groups), json.dumps(projects), json.dumps(manages), hr))
    conn.commit()

def seed_sample_conversation(conn):
    from kms_app.web import routes
    cid = conn.execute("SELECT conv_id FROM conversations LIMIT 1").fetchone()
    if cid: return
    from kms_app.conversation import store as cstore
    conv = cstore.create(conn, "eng_pd1", title="Hỏi về DCM (mẫu)")
    me = db.row_to_subject(conn.execute("SELECT * FROM users WHERE user_id='eng_pd1'").fetchone())
    routes.run_turn(conn, me, conv, "Mô hình phân quyền DCM của KMS hoạt động thế nào?")

def run_seed():
    db.init_db()
    write_documents()
    conn = db.connect()
    try:
        seed_users(conn)
        istore.ingest_all(conn)
        seed_sample_conversation(conn)
    finally:
        conn.close()
    print("  Seed xong: users + documents + chunks + 1 hội thoại mẫu.")
