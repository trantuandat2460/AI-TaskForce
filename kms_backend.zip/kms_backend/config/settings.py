"""Cấu hình tập trung cho KMS backend. Mọi đường dẫn / hằng số sống ở đây.

Triển khai thật: chỉnh HOST/PORT, trỏ DATA_DIR sang volume bền vững, bật
COOKIE_SECURE=True sau reverse proxy HTTPS, thay DEMO_AUTH bằng SSO/OIDC,
và đổi LLM_BACKEND sang 'http' (xem kms_app/llm/client.py).
"""
from pathlib import Path

# ---- Đường dẫn (code tách khỏi dữ liệu) ----
BASE_DIR      = Path(__file__).resolve().parent.parent          # gốc project
DATA_DIR      = BASE_DIR / "data"                               # TẤT CẢ dữ liệu runtime nằm ở đây
DB_PATH       = DATA_DIR / "kms.db"                             # SQLite — mở bằng bất kỳ trình xem nào
DOCUMENTS_DIR = DATA_DIR / "documents"                          # kho markdown nguồn (bạn nhìn thấy trực tiếp)
UPLOADS_DIR   = DATA_DIR / "uploads"                            # file thô trước khi ingest
EXPORTS_DIR   = DATA_DIR / "exports"                            # nơi xuất audit.csv ...
SECRET_FILE   = DATA_DIR / "secret.key"                         # khoá HMAC cho chuỗi audit (tự sinh, chmod 600)

# ---- Mạng ----
HOST = "127.0.0.1"
PORT = 8077

# ---- Phiên (control-plane §21) ----
SESSION_TTL_SECONDS = 8 * 3600
SESSION_COOKIE      = "kms_session"
COOKIE_SECURE       = False        # True khi chạy sau HTTPS thật

# ---- Auth ----
DEMO_AUTH = True                   # demo: mật khẩu = user_id. Thật: tắt + dùng SSO.
PBKDF2_ROUNDS = 100_000

# ---- Mô hình phân loại ----
CLASS_RANK = {"C1": 1, "C2": 2, "C3": 3}

# ---- Trần vai trò (kind nào vai trò được chạm) ----
ROLE_KINDS = {
    "ADMIN": "*",
    "ENGINEER": {"IP","SPEC_OVERVIEW","SPEC_DETAIL","TESTBENCH","FOUNDRY","PROGRESS_REPORT","PLAN","METADATA","PUBLIC","FA","PII"},
    "LEADER":   {"SPEC_OVERVIEW","PROGRESS_REPORT","PLAN","METADATA","PUBLIC","FA","PII"},
    "PM":       {"PROGRESS_REPORT","PLAN","METADATA","PUBLIC"},
    "HR":       {"PUBLIC","METADATA","PII"},
}

# ---- Retention (A17/P35) ----
CONVERSATION_RETAIN_DAYS = 180

# ---- LLM (llm/client.py) ----
LLM_BACKEND   = "stub"             # 'stub' = mô phỏng tất định, offline. 'http' = gọi vLLM/Viettel AI.
LLM_HTTP_URL  = "http://127.0.0.1:8000/v1/chat/completions"
LLM_MODEL     = "Qwen2.5-72B-Instruct-AWQ"
